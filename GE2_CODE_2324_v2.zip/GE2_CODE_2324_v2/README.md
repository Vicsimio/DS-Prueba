# Guided Exercise 2.1
# student 1  [email] [github user]
# student 2 [email] [github user]
# student 3  [email] [github user]